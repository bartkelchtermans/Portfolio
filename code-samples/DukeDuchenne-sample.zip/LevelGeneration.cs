﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This is a level algorithm for an endless runner in Unity.

// Level generation works by subdividing the level up in segments.
// Each of these segments consist of one floor and wall prefab, as well as population.
// There are 20 segments spawned at all times, once one is deleted, a new one is generated.

// To run this system, a script is required: LevelSegment.cs
// LevelSegment holds the booleans for all special objects that are spawned in each level.
// A _segmentPopulation list saves all LevelSegment scripts for each spawned segment, saving what is in the segment and what isn't.
// _futureSegments is a list that saves what can be spawned in the future, by default everything is true.
// When a new segment is created, the firstmost _futureSegment element is copied to check all values to see what can be spawned.
// While spawning, whenever a special object is spawned, the value is untouched, however when it isn't spawned, the value is set to false.
// This results in having a list that holds what has been spawned so the algorithm can optimally follow the desired difficulty, 
// as well as spawn desired objects or specifically not spawn objects. 

// Generation and degeneration works by placing a trigger on the camera, at a large negative x value.
// Each segment spawns a collider below the segment, out of the scope of the scene, but within that of the trigger.
// Whenever the trigger detects a collider, the first segment is deleted and a new one is generated.

public class LevelGeneration : MonoBehaviour {
	
	[SerializeField]
	Vector2 _spawnLocation = new Vector2(-0.2f, 0);
	float _wallPrefabWidth = 6;
	int _backgroundCounter = 0;
	int _previousObstacle = 0;

	int _segmentCounter = 0;
	int _segmentDeleteCounter = 0;
	List<LevelSegment> _segmentPopulation = new List<LevelSegment>();
	List<LevelSegment> _futureSegments = new List<LevelSegment>();
	List<List<GameObject>> _segmentObjects = new List<List<GameObject>>();

	[SerializeField]
	float _idealDifficulty = 1.04f;
	[SerializeField]
	float _pickupOccurrenceFactor = 0.1f;
	[SerializeField]
	int _lightOccurrence = 5;
	int _lightCounter = 0;

	// PREFABS
	[SerializeField]
	GameObject _segmentTrigger;

	// Environment prefabs
	[SerializeField]
	private GameObject[] _wallPrefabs;
	[SerializeField]
	private GameObject[] _floorPrefabs;
	[SerializeField]
	private GameObject[] _lightPrefabs;

	// Population prefabs
	[SerializeField]
	private GameObject[] _obstaclePrefabs;
	[SerializeField]
	private GameObject[] _interactiblePrefabs;
	[SerializeField]
	private GameObject[] _pickupPrefabs;
	[SerializeField]
	private GameObject _currencyPrefab;

	// Decoration prefabs
	[SerializeField]
	private GameObject[] _backgroundPrefabs;
	[SerializeField]
	private GameObject[] _foregroundPrefabs;
	[SerializeField]
	private GameObject[] _detailPrefabs;

	// Spawn chance
	int _healthPickupPreference = 0;
	int _eventSpawnChance = 25;
	int _ventSpawnChance = 20;
	int _decorationSpawnChance = 40;
	int _foregroundSpawnChance = 40;
	int _jumppadSpawnChance = 30;

	// Difficulty
	List<int> _spawnedDifficulty = new List<int>();

	// Use this for initialization
	void Start () {
		// Spawn level
		SpawnStartLevel();
	}

	void SpawnStartLevel()
	{
		_futureSegments.Add(new LevelSegment(false));
		for (int i = 0; i < 19; i++)
		{
			_futureSegments.Add(new LevelSegment(true));
		}

		for (int i = 0; i < 20; i++)
		{
			InstantiateSegment();
		}
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.name.Contains("segmentTrigger"))
		{
			RemoveSegment(0);
			_segmentObjects.RemoveAt(0);
			_segmentDeleteCounter--;
			InstantiateSegment();
		}
	}

	void InstantiateSegment()
	{
		// Build current segment based on the first future segment
		_segmentPopulation.Add(_futureSegments[0]);

		// Remove first future segment and add a new one at the end
		_futureSegments.RemoveAt(0);
		_futureSegments.Add(new LevelSegment(true));

		// Add a difficulty
		_spawnedDifficulty.Add(0);

		// Add a segmentObjects entry
		_segmentObjects.Add(new List<GameObject>());

		// SPAWNING _______________________________________________________________________________________
		///////////////////////////////////////////////////////////////////////////////////////////////////

		// Spawn the segment trigger
		Instantiate(_segmentTrigger, new Vector3(_spawnLocation.x, _spawnLocation.y - 5, 0), Quaternion.identity);

		// STRUCTURE ______________________________________________________________________________________

		// Spawn wall
		SpawnWall(new Vector3(_spawnLocation.x, _spawnLocation.y - 1, 3.5f));

		// Spawn floor
		SpawnFloor(new Vector3(_spawnLocation.x, _spawnLocation.y, 0));

		// POPULATION _____________________________________________________________________________________

		// Spawn obstacle
		SpawnObstacle(new Vector3(_spawnLocation.x, _spawnLocation.y, 0));

		// Spawn light
		SpawnLight(new Vector3(_spawnLocation.x, _spawnLocation.y + 8, 0));

		// Spawn pickup
		SpawnPickup(new Vector3(_spawnLocation.x, _spawnLocation.y, 0));

		// Spawn currency
		if ((_segmentPopulation[_segmentCounter].Currency && _segmentCounter > 1 && !_segmentPopulation[_segmentCounter - 1].Currency &&
		(_segmentPopulation[_segmentCounter].Pitfall || !_segmentPopulation[_segmentCounter].Occupied ||
		(!_segmentPopulation[_segmentCounter].Obstacle && !_segmentPopulation[_segmentCounter].Pitfall && !_segmentPopulation[_segmentCounter].Pickup && !_segmentPopulation[_segmentCounter].Occupied))))
		{
			SpawnCurrency(new Vector3(_spawnLocation.x, _spawnLocation.y + Random.Range(2f, 3.5f), 0), Random.Range(0, 5));
		}
		else 
		{
			_segmentPopulation[_segmentCounter].Currency = false;
		}

		// DECORATION _____________________________________________________________________________________

		// Background
		float randomZ = Random.Range(-1, 1);
		if (_backgroundCounter % 10 == 0) Instantiate(_backgroundPrefabs[0], new Vector3(_spawnLocation.x, _spawnLocation.y + 5, 30 + randomZ), new Quaternion(0,180,0,0));
		if (_backgroundCounter % 5 == 0) Instantiate(_backgroundPrefabs[1], new Vector3(_spawnLocation.x, _spawnLocation.y - 1, 0 + randomZ), new Quaternion(0,180,0,0));
		_backgroundCounter++;

		// Foreground
		SpawnForeground(_spawnLocation);

		// Decoration
		SpawnDecoration();
		
		// Increment spawn position x
		_spawnLocation.x += _wallPrefabWidth;

		// Increment counters
		_healthPickupPreference++;

		// Increment segment counters
		_segmentCounter++;
		_segmentDeleteCounter++;

		// Increase difficulty
		_idealDifficulty += 0.00001f;
	}

	void RemoveSegment(int index)
	{
		for (int i = 0; i < _segmentObjects[index].Count; i++)
		{
			Destroy(_segmentObjects[index][i].gameObject);
		}
	}

	// SPAWNING _______________________________________________________________________________________
	///////////////////////////////////////////////////////////////////////////////////////////////////

	void SpawnWall(Vector3 position)
	{
		int randWallInt = 0;

		if ((_segmentCounter > 0) && (!_segmentPopulation[_segmentCounter-1].Window && (_segmentPopulation[_segmentCounter].Window)))
		{
			// randWallInt = random wall
		}
		else
		{
			// randWallInt = random wall without window
		}

		GameObject spawnedWall = Instantiate(_wallPrefabs[randWallInt], position, new Quaternion(0,0,0,0));
		_segmentObjects[_segmentDeleteCounter].Add(spawnedWall);
		
		if (randWallInt < 2)
		{
			_segmentPopulation[_segmentCounter].Window = false;	
		}
	}

	void SpawnFloor(Vector3 position)
	{
		int randFloorInt = Random.Range(0,100);
		float diffFactor = CalculateAverageDifficulty(3);

		if ((randFloorInt > _floorPrefabs[0].GetComponent<LevelObject>().SpawnChance) &&
		(_segmentPopulation[_segmentCounter].Pitfall && (!_segmentPopulation[_segmentCounter].Window && (diffFactor < _idealDifficulty) && 
		(_segmentCounter > 0) && (!_segmentPopulation[_segmentCounter - 1].Pitfall))))
		{
			// Spawn pitfall
			GameObject spawnedObstacle = Instantiate(_floorPrefabs[1], position, Quaternion.identity);
			_segmentObjects[_segmentDeleteCounter].Add(spawnedObstacle);
			_spawnedDifficulty[_segmentCounter] = spawnedObstacle.GetComponent<LevelObstacle>().Difficulty;
			_segmentPopulation[_segmentCounter].Occupied = true;

			// Spawn jumppad
			if (!_segmentPopulation[_segmentCounter - 1].Obstacle && !_segmentPopulation[_segmentCounter - 1].Pickup && !_segmentPopulation[_segmentCounter - 1].Occupied)
			{
				int randJumpPadChance = Random.Range(0, 100);
				if (randJumpPadChance >= _jumppadSpawnChance) 
				{
					GameObject spawnedJumpPad = Instantiate(_interactiblePrefabs[0], new Vector3(_spawnLocation.x - _wallPrefabWidth, _spawnLocation.y, 0), Quaternion.identity);
					_segmentObjects[_segmentDeleteCounter].Add(spawnedJumpPad);
				}

				_segmentPopulation[_segmentCounter - 1].Occupied = true;
			}
		}
		else
		{
			// Spawn regular floor
			GameObject spawnedFloor = Instantiate(_floorPrefabs[0], position, Quaternion.Euler(-90,180,0));
			_segmentObjects[_segmentDeleteCounter].Add(spawnedFloor);
			_segmentPopulation[_segmentCounter].Pitfall = false;
		}
	}

	void SpawnLight(Vector3 position)
	{
		if (_lightCounter == _lightOccurrence)
		{
			if (_segmentPopulation[_segmentCounter].Light)
			{
				// Spawn light
				GameObject spawnedLight = Instantiate(_lightPrefabs[0], position, Quaternion.identity);
				_segmentObjects[_segmentDeleteCounter].Add(spawnedLight);

				_lightCounter = 0;
			}
		}
		else
		{
			_segmentPopulation[_segmentCounter].Light = false;
			_lightCounter++;
		}
	}

	void SpawnObstacle(Vector3 position)
	{
		// Randomize X
		position.x -= _wallPrefabWidth * 0.25f;
		position.x += Random.Range(0, _wallPrefabWidth / 2);

		if ((_segmentPopulation[_segmentCounter].Obstacle) && (!_segmentPopulation[_segmentCounter].Pitfall) && (!_segmentPopulation[_segmentCounter].Occupied))
		{
			// Calculate difficulty factor based on last three segments
			float diffFactor = CalculateAverageDifficulty(3);

			// Decide if and what to spawn
			if (diffFactor < _idealDifficulty * 0.9f)
			{
				int randObstacleInt;
				// Don't spawn the same obstacle twice, don't spawn a wall-obstacle with a window
				do
				{
					randObstacleInt = Random.Range(0, 9);
				} while ((randObstacleInt == _previousObstacle) || ((randObstacleInt == 1 || randObstacleInt == 7 || randObstacleInt == 8) && _segmentPopulation[_segmentCounter].Window));

				GameObject spawnedObstacle = Instantiate(_obstaclePrefabs[randObstacleInt], position, Quaternion.identity);
				
				_segmentObjects[_segmentDeleteCounter].Add(spawnedObstacle);
				_spawnedDifficulty[_segmentCounter] = spawnedObstacle.GetComponent<LevelObstacle>().Difficulty;
				_previousObstacle = randObstacleInt;

				// Specific obstacle currency, pickup & jumppad
				if (randObstacleInt == 6)
				{
					// Spawn currency
					SpawnCurrency( new Vector3(_spawnLocation.x + _wallPrefabWidth, _spawnLocation.y + 0.75f, 0), 0);
					_segmentPopulation[_segmentCounter].Currency = false;

					if (spawnedObstacle.GetComponent<BiomeMeshChange>().GetID() == 0)
					{
						// Spawn jump pad
						if ((_segmentCounter > 0) && (!_segmentPopulation[_segmentCounter - 1].Obstacle) && (!_segmentPopulation[_segmentCounter - 1].Pickup) && (!_segmentPopulation[_segmentCounter - 1].Pitfall) && (!_segmentPopulation[_segmentCounter - 1].Occupied))
						{
							GameObject spawnedJumpPad = Instantiate(_interactiblePrefabs[1], new Vector3(_spawnLocation.x - _wallPrefabWidth, _spawnLocation.y, 0), Quaternion.identity);

							_segmentObjects[_segmentDeleteCounter].Add(spawnedJumpPad);
							_segmentPopulation[_segmentCounter - 1].Occupied = true;

							// Spawn pickup
							GameObject spawnedPickup = Instantiate(_pickupPrefabs[Random.Range(0, 4)], new Vector3(_spawnLocation.x + _wallPrefabWidth, _spawnLocation.y + 5, 0), Quaternion.identity);
							_segmentObjects[_segmentDeleteCounter].Add(spawnedPickup);
						}
					}

					_futureSegments[0].SetValues(false);
					_futureSegments[1].SetValues(false);
				}
				else
				{
					// Spawn jump pad
					if ((spawnedObstacle.GetComponent<LevelObstacle>().PassMethod >= 1) && (_segmentCounter > 0) && (!_segmentPopulation[_segmentCounter - 1].Obstacle) && (!_segmentPopulation[_segmentCounter - 1].Pickup) && (!_segmentPopulation[_segmentCounter - 1].Pitfall) && (!_segmentPopulation[_segmentCounter - 1].Occupied))
					{						
						int randJumpPadChance = Random.Range(0, 10);
						if (randJumpPadChance >= 5) 
						{
							GameObject spawnedJumpPad = Instantiate(_interactiblePrefabs[0], new Vector3(_spawnLocation.x - _wallPrefabWidth, _spawnLocation.y, 0), Quaternion.identity);
							_segmentObjects[_segmentDeleteCounter].Add(spawnedJumpPad);
							_segmentPopulation[_segmentCounter - 1].Occupied = true;
						}
					}
				}

				// If ceiling-obstacle spawned don't spawn a light
				if ((randObstacleInt == 6) || (randObstacleInt == 7)) _segmentPopulation[_segmentCounter].Light = false;

				_segmentPopulation[_segmentCounter].Obstacle = true;
				_segmentPopulation[_segmentCounter].Occupied = true;
			}
			else
			{
				_segmentPopulation[_segmentCounter].Obstacle = false;
			}
		}
		else
		{
			_segmentPopulation[_segmentCounter].Obstacle = false;
		}
	}

	void SpawnPickup(Vector3 position)
	{
		if ((_segmentPopulation[_segmentCounter].Pickup) && (!_segmentPopulation[_segmentCounter].Obstacle) && (!_segmentPopulation[_segmentCounter].Pitfall && 
		(!_segmentPopulation[_segmentCounter].Occupied)) && (CalculateAverageDifficulty(3) >= _idealDifficulty))
		{
			int randPickupInt = Random.Range(0,100);
			int randPickup = 0;

			float healthFactor = _healthPickupPreference * _pickupOccurrenceFactor;

			for (int i = 0; i < _pickupPrefabs.Length; i++)
			{
				int pickupSpawnChance = _pickupPrefabs[i].GetComponent<LevelObject>().SpawnChance;
				if (i < 2) pickupSpawnChance = _pickupPrefabs[i].GetComponent<LevelObject>().SpawnChance + (int)healthFactor;
				if (pickupSpawnChance < randPickupInt)
				{
					randPickupInt -= _pickupPrefabs[i].GetComponent<LevelObject>().SpawnChance;
				}
				else
				{
					randPickup = i;
					break;
				}
			}

			GameObject spawnedPickup = Instantiate(_pickupPrefabs[randPickup], position, Quaternion.identity);
			_segmentObjects[_segmentDeleteCounter].Add(spawnedPickup);
			
			// Small health pickup
			if (randPickup == 0) _healthPickupPreference /= 2;

			// Large health pickup
			if (randPickup == 1) _healthPickupPreference = 0;

			_segmentPopulation[_segmentCounter].Pickup = true;
		}
		else
		{
			_segmentPopulation[_segmentCounter].Pickup = false;
		}
	}

	void SpawnCurrency(Vector3 position, int formation)
	{
		switch (formation)
		{
			// Single row
			case 0:
			for (int i = 0; i < Random.Range(4, 7); i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			break;
			// Double row
			case 1:
			int randomRange1 = Random.Range(2, 5);
			for (int i = 0; i < randomRange1; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < randomRange1; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			break;
			// Triple row
			case 2:
			int randomRange2 = Random.Range(2, 5);
			for (int i = 0; i < randomRange2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < randomRange2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < randomRange2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y - 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y - 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			break;
			// Square
			case 3:
			for (int i = 0; i < 2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y - 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y - 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < 2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < 2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			break;
			// Diamond
			case 4:
			Instantiate(_currencyPrefab, new Vector3(position.x, position.y + 1f, position.z), Quaternion.Euler(-90,90,0));
			for (int i = 0; i < 2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y - 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y - 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < 3; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			for (int i = 0; i < 2; i++)
			{
				Instantiate(_currencyPrefab, new Vector3(position.x - ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
				if (i != 0) Instantiate(_currencyPrefab, new Vector3(position.x + ((float)i / 2), position.y + 0.5f, position.z), Quaternion.Euler(-90,90,0));
				_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			}
			Instantiate(_currencyPrefab, new Vector3(position.x, position.y - 1f, position.z), Quaternion.Euler(-90,90,0));
			_segmentObjects[_segmentDeleteCounter].Add(_currencyPrefab);
			break;
		}
	}

	void SpawnDecoration()
	{
		if (_segmentPopulation[_segmentCounter].Decoration && !_segmentPopulation[_segmentCounter].Obstacle) 
		{
			int randDecorationInt = Random.Range(0,100);
			if (randDecorationInt < _decorationSpawnChance)
			{
				int randElementInt = Random.Range(0, _detailPrefabs.Length);
				switch (randElementInt)
				{
					case 0:
					// Vents
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;

					case 1:
					// Monitor 1
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;

					case 2:
					// Monitor 2
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;
					
					case 3:
					// Lowhanging ceiling
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;
					
					case 4:
					// Controller
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;
				}
			}
		}
	}

	void SpawnForeground(Vector3 position)
	{
		if (!_segmentPopulation[_segmentCounter].Obstacle)
		{
			int randForegroundInt = Random.Range(0,100);
			if (randForegroundInt < _foregroundSpawnChance)
			{
				int randElementInt = Random.Range(0, _foregroundPrefabs.Length);
				switch (randElementInt)
				{
					case 0:
					// Single pipe
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;

					case 1:
					// Single small pipe
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;

					case 2:
					// Double small pipe
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;
					
					case 3:
					// Single bended pipe
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;
					
					case 4:
					// Single small pipe and bended pipe
					_segmentObjects[_segmentDeleteCounter].Add(spawnedDecoration);
					break;
				}
			}
		}
	}

	float CalculateAverageDifficulty(int length)
	{
		float averageDifficulty = 0;

		if (_spawnedDifficulty.Count <= length)
		{
			for (int i = 0; i < _spawnedDifficulty.Count; i++)
			{
				averageDifficulty += _spawnedDifficulty[i];		
			}
			averageDifficulty /= _spawnedDifficulty.Count;
		}
		else
		{
			for (int i = _spawnedDifficulty.Count - 1; i > _spawnedDifficulty.Count - (1 + length); i--)
			{
				averageDifficulty += _spawnedDifficulty[i];		
			}
			averageDifficulty /= length;
		}
		
		return averageDifficulty;
	}

	float CalculateSumDifficulty(int length)
	{
		float sumDifficulty = 0;

		if (_spawnedDifficulty.Count <= length)
		{
			for (int i = 0; i < _spawnedDifficulty.Count; i++)
			{
				sumDifficulty += _spawnedDifficulty[i];		
			}
		}
		else
		{
			for (int i = _spawnedDifficulty.Count - 1; i > _spawnedDifficulty.Count - (1 + length); i--)
			{
				sumDifficulty += _spawnedDifficulty[i];		
			}
		}
		
		return sumDifficulty;
	}
}
