// ____________________________________________________________________________________________
// SERVICE.JS
// This file contains code necessary for editing services of Bartium.
// This code works on the second layer of Bartium, the web app.
// ____________________________________________________________________________________________

var serviceEdit = [4];
var serviceEditPost = [4];

function EditService()
{
  // Parent
  let navParent = document.getElementById(serviceEditPost[3]);

	// NavItem
	let navItems = document.getElementById(serviceEdit[3]).childNodes;
	let navIndex;

	for (var i = 0; i < navItems.length; i++) {
		if (navItems[i].id != null) {
			if (navItems[i].id.substring(8) == serviceEdit[1])
			{
				navIndex = i;
			}
		}
	}
	if (navIndex == null) {
		alert-error("Error - no valid navItem found.")
	}

	// Fix title length if too long
	let title;
	if (serviceEditPost[0].length > 20) {
	  title = serviceEditPost[0].substring(0, 18);
	  title = title + "...";
	}
	else {
    title = serviceEditPost[0];
  }

	navItems[navIndex].childNodes[0].childNodes[1].childNodes[0].nodeValue = title;
	navItems[navIndex].id = 'navItem-' + serviceEditPost[1];
	navItems[navIndex].childNodes[0].childNodes[0].setAttribute('class', serviceEditPost[2]);

  // Set new parent
  if (serviceEditPost[3] != serviceEdit[3]) {
    navParent.appendChild(navItems[navIndex]);
  }

	// Webview
	DeleteWebview(serviceEdit[1]);
	AddWebview(serviceEditPost[1]);

	// Saving BartItems
  SaveBItems();
}