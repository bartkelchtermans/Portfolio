// ____________________________________________________________________________________________
// EDIT.JS
// This file contains only code for the page to edit a service.
// All general code for all pages can be found in the general page source file.
// This code works on the third layer of Bartium, within a webview, in this case the edit page.
// ____________________________________________________________________________________________

function SaveServiceEdit()
{
  const {ipcRenderer} = require('electron');

  // Getting the input fields
  let txtName = document.getElementById('serviceName');
  let txtURL = document.getElementById('serviceURL');
  let chkAuto = document.getElementById('chkAutomaticIcon');
  let groupDrop = document.getElementById('groupDrop');

  // Getting values
  let editServiceName = txtName.value;
  let editServiceURL = URLModify();
  if (chkAuto.checked) {
    // Giving it an unexisting icon code so the space stays empty and can be filled up later
    selectedServiceIcon = 'fa fa-bartium-favicon-dev';
  }

  let editServiceParent = groupDrop.value;

  // Sending the values to the webview listener
  ipcRenderer.sendToHost('SaveServiceEdit', editServiceName, editServiceURL, selectedServiceIcon, editServiceParent);

  // Send the command to the listener to save the bItems
  ipcRenderer.sendToHost('SavebItems');
}

function CancelEdit()
{
  const {ipcRenderer} = require('electron');
  ipcRenderer.sendToHost('CancelEdit');
}