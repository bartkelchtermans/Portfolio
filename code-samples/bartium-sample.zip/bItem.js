// ____________________________________________________________________________________________
// BITEM.JS
// bartItems are offline stored items that each hold a service
// This code works on the second layer of Bartium, the web app.
// ____________________________________________________________________________________________

function SavebItems()
{
  //          Delete all keys  
  let itemIndex = 0;

  while (config.has("bartItems." + itemIndex)) {
    config.delete("bartItems." + itemIndex);
    itemIndex++;
  }

  //          Add all new keys
  // Find the parent that holds all the services
  let navItemList = document.getElementById("Services");
  let navItems = navItemList.childNodes;

  // Iterate over all children and save it
  for (var i = 0; i < navItems.length; i++) {
    if (navItems[i].id != null) {
      if (navItems[i].id.substring(0, 5) == 'group') 
      {
        // Call the function to save a group
        SavebGroup(navItems[i]);
      }
      else {
        // Call the function to save a service
        SavebService(navItems[i]);
      }
    }
  }
}
