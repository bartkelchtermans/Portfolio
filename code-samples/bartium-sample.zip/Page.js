// ____________________________________________________________________________________________
// PAGE.JS
// This file contains code necessary for all pages of Bartium.
// A page is a fixed webview with either the settings, add or edit page.
// This code works on the second layer of Bartium, the web app.
// ____________________________________________________________________________________________

var selectedServiceIcon;
var websiteExists;
var checkingWebExists = false;

function AddPage()
{
  let link = arguments[1];

  // Create webview
  let wview = document.createElement('webview');
  wview.setAttribute('id', link);
  wview.setAttribute('src', link);
  wview.setAttribute('autosize', 'on');
  wview.setAttribute('class', 'webview');
  wview.setAttribute('minwidth', '576');
  wview.setAttribute('minheight', '500');
  wview.setAttribute('plugins', 'true');
  wview.setAttribute('allowpopups', 'true');
  wview.setAttribute('style', 'z-index: -500; display: none');
  wview.setAttribute('nodeintegration', '');

  // Event listener for IPC
  wview.addEventListener('ipc-message', (e) =>
  {
    if (e.channel == "AddService") {
			let locService;

			if (e.args[3] == '') {
				locService = 'Services'
			}
			else
			{
				// Find the location for services
				for (var i = 0; i < arrGroups.length; i++) {
					let title = arrGroups[i].childNodes[0].childNodes[2].innerHTML;

					if (title.trim() == e.args[3].trim()) {
						locService = 'services-' + title.trim();
						break;
					}
				}
			}

      let name = e.args[0];
      let url = e.args[1];
      let icon = e.args[2];

			AddService(name.trim(), url.trim(), icon.trim(), locService.trim());

      // Add local bartItem
      AddBItem(0, e.args[0], e.args[1], e.args[2], 'Services');
    }

		if (e.channel == "SaveServiceEdit") {
			serviceEditPost[0] = e.args[0];
			serviceEditPost[1] = e.args[1];
			serviceEditPost[2] = e.args[2];
      serviceEditPost[3] = 'services-' + e.args[3];

			EditService();
		}

		if (e.channel == "CancelEdit") {
			OpenService(serviceEdit[1]);
		}

    if (e.channel == "SavebItems") {
      SavebItems();
    }
  });
}

// Code to check if a url exists and visualizes its subsequent success or failure
function URLCheck()
{
  // Get status icons
  let URLspinner = document.getElementById("URLcheck");
  let URLtrue = document.getElementById("URLtrue");
  let URLfalse = document.getElementById("URLfalse");

  // Set busy status
  URLspinner.setAttribute('style', 'font-size: 18px; position:absolute; right: 12px; top: 34px; color: #24b367; pointer-events: none;');
  URLtrue.setAttribute('style', 'display: none');
  URLfalse.setAttribute('style', 'display: none');

  // Get textboxes & buttons
  let txtName = document.getElementById('serviceName');
  let txtGroupName = document.getElementById('groupName');
  let txtURL = document.getElementById('serviceURL');
  let btnSave = document.getElementById('btnServiceSave');
  let btnGroupSave = document.getElementById('btnGroupSave');
  let checkboxAuto = document.getElementById('chkAutomaticIcon');

  // Check textbox value
  let newServiceURL = URLModify();
  if (newServiceURL.length > 7)
  {
    // Check if URL exists
    $.get(newServiceURL)
      .done(function() {
        URLspinner.setAttribute('style', 'display: none');
        URLtrue.setAttribute('style', 'font-size: 20px; position:absolute; right: 13px; top: 32px; color: #24b367; pointer-events: none;');

        websiteExists = true;
      }).fail(function() {
        URLspinner.setAttribute('style', 'display: none');
        URLfalse.setAttribute('style', 'font-size: 20px; position:absolute; right: 14px; top: 32px; color: #DD4B39; pointer-events: none;');

        websiteExists = false;
      })
  }
  else {
    URLspinner.setAttribute('style', 'display: none');
    URLtrue.setAttribute('style', 'display: none');
    URLfalse.setAttribute('style', 'display: none');
  }
}

