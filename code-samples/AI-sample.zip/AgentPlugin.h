// #include "stdafx.h"
#include "FSM.h"

class AgentPlugin
{
public:
	AgentPlugin();
	~AgentPlugin();

	void Start();

protected:

	// Agent
	bool m_EnemySpotted = false;

	// Behaviour
    std::vector<b2Vec2> m_TargetHouses;
	std::vector<b2Vec2> m_ClearedHouses;
	std::vector<b2Vec2> m_GarbagePositions;
	std::vector<b2Vec2> m_Enemies;
	b2Vec2 m_Target;
	b2Vec2 m_FinalTarget;
	b2Vec2 m_ExpOrigin;
	b2Vec2 m_AgentPos;
	bool m_SetTarget;
	bool m_EnemyLocked = false;
	float m_Aggression;

    // Finite state machine
	FSM* m_pStateMachine = nullptr;

	std::vector<FSMConditionBase*> m_Conditions = {};
	std::vector<FSMDelegateBase*> m_Delegates = {};
	std::vector<FSMState*> m_States = {};
}

