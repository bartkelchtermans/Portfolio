#include "AgentPlugin.h"

void AgentPlugin::Start()
{
	// CONDITIONING LAMBDAS
	// The agent has no targets
	auto hasNoTargets = [&]()->bool { return (m_TargetItems.size() == 0 && m_TargetHouses.size() == 0); };
	// The agent has targets
	auto hasTargets = [&]()->bool { return !(m_TargetItems.size() == 0 && m_TargetHouses.size() == 0); };
	// Enemy in sight
	auto enemySpotted = [&]()->bool { return m_EnemySpotted; };
	// No enemy in sight
	auto noEnemySpotted = [&]()->bool { return !m_EnemySpotted; };

	// TRANSITION CONDITIONS
	FSMConditionBase* conHasNoTargets = new FSMCondition<>(
	{ FSMDelegateContainer<bool>(hasNoTargets) });
	m_Conditions.push_back(conHasNoTargets);

	FSMConditionBase* conHasTargets = new FSMCondition<>(
	{ FSMDelegateContainer<bool>(hasTargets) });
	m_Conditions.push_back(conHasTargets);

	FSMConditionBase* conEnemySpotted = new FSMCondition<>(
	{ FSMDelegateContainer<bool>(enemySpotted) });
	m_Conditions.push_back(conEnemySpotted);

	FSMConditionBase* conNoEnemySpotted = new FSMCondition<>(
	{ FSMDelegateContainer<bool>(noEnemySpotted) });
	m_Conditions.push_back(conNoEnemySpotted);

	// DELEGATES
	FSMDelegateBase* funcExplore = new FSMDelegate<b2Vec2&, std::vector<b2Vec2>&, std::vector<b2Vec2>&, b2Vec2&, b2Vec2&, bool&>(
	{ FSMDelegateContainer<void, b2Vec2&, std::vector<b2Vec2>&, std::vector<b2Vec2>&, b2Vec2&, b2Vec2&, bool&>(Explore, m_AgentPos, m_TargetItems, m_TargetHouses, m_FinalTarget, m_ExpOrigin, m_SetTarget) });
	m_Delegates.push_back(funcExplore);
	FSMDelegateBase* funcTravel = new FSMDelegate<AgentInfo, std::vector<b2Vec2>&, std::vector<b2Vec2>&, b2Vec2&, bool&>(
	{ FSMDelegateContainer<void, AgentInfo, std::vector<b2Vec2>&, std::vector<b2Vec2>&, b2Vec2&, bool&>(Travel, AGENT_GetInfo(), m_TargetItems, m_TargetHouses, m_FinalTarget, m_SetTarget) });
	m_Delegates.push_back(funcTravel);
	FSMDelegateBase* funcEngage = new FSMDelegate<float&, b2Vec2&, std::vector<b2Vec2>&, bool&, b2Vec2&, bool&>(
	{ FSMDelegateContainer<void, float&, b2Vec2&, std::vector<b2Vec2>&, bool&,b2Vec2&, bool&>(Engage, m_Aggression, m_AgentPos, m_Enemies, m_EnemyLocked, m_FinalTarget, m_SetTarget) });
	m_Delegates.push_back(funcEngage);

	// STATES
	FSMState* stateExploration = new FSMState();
	m_States.push_back(stateExploration);
	FSMState* stateMovement = new FSMState();
	m_States.push_back(stateMovement);
	FSMState* stateCombat = new FSMState();
	m_States.push_back(stateCombat);

	// BUILD STATES
	// Exploration
	stateExploration->SetActions({ funcExplore });
	stateExploration->SetTransitions({
		FSMTransition({ conEnemySpotted },{}, stateCombat),
		FSMTransition({ conHasTargets },{}, stateMovement) });
	// Movement
	stateMovement->SetActions({ funcTravel });
	stateMovement->SetTransitions({
		FSMTransition({ conEnemySpotted },{}, stateCombat),
		FSMTransition({ conHasNoTargets },{}, stateExploration) });
	// Combat
	stateCombat->SetActions({ funcEngage });
	stateCombat->SetTransitions({
		FSMTransition({ conNoEnemySpotted },{}, stateExploration) });

	// CREATE STATE MACHINE
	m_pStateMachine = new FSM({ stateExploration, stateMovement, stateCombat }, stateExploration);

	// START STATE MACHINE
	m_pStateMachine->Start();
}