#include "FSM.h"

void FSM::Start()
{}

void FSM::Update()
{
	// Check all transitions for current state and see if a transition is required
	auto transitions = m_CurrentState->GetTransitions();
	auto transitionTriggered = false;
	FSMTransition triggeredTransition = {};
	for(auto trans : transitions)
	{
		transitionTriggered = trans.IsTriggered();
		if(transitionTriggered)
		{
			triggeredTransition = trans;
			break;
		}
	}

	// If a transition triggered, execute the switch
	if(transitionTriggered)
	{
		//Get target state
		auto targetState = triggeredTransition.GetTargetState();

		//End current state, do transition actions and enter the new state
		m_CurrentState->RunExitActions();
		triggeredTransition.RunActions();
		targetState->RunEntryActions();

		//Switch
		m_CurrentState = targetState;
	}
	else
	{
		m_CurrentState->RunActions();
	}
}